package com.car.model;

public class CompanyDTO {

	private String company_business_no;
	private String company_name;
	private String company_ceo_name;
	private String company_addr;
	private String company_phone;
	private String company_found_date;
	private String company_account;

	public String getCompany_business_no() {
		return company_business_no;
	}

	public void setCompany_business_no(String company_business_no) {
		this.company_business_no = company_business_no;
	}

	public String getCompany_name() {
		return company_name;
	}

	public void setCompany_name(String company_name) {
		this.company_name = company_name;
	}

	public String getCompany_ceo_name() {
		return company_ceo_name;
	}

	public void setCompany_ceo_name(String company_ceo_name) {
		this.company_ceo_name = company_ceo_name;
	}

	public String getCompany_addr() {
		return company_addr;
	}

	public void setCompany_addr(String company_addr) {
		this.company_addr = company_addr;
	}

	public String getCompany_phone() {
		return company_phone;
	}

	public void setCompany_phone(String company_phone) {
		this.company_phone = company_phone;
	}

	public String getCompany_found_date() {
		return company_found_date;
	}

	public void setCompany_found_date(String company_found_date) {
		this.company_found_date = company_found_date;
	}

	public String getCompany_account() {
		return company_account;
	}

	public void setCompany_account(String company_account) {
		this.company_account = company_account;
	}

}
