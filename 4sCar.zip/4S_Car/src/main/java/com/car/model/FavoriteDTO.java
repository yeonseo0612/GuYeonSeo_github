package com.car.model;

public class FavoriteDTO {

	private int favorite_no;
	private String favorite_user_no;
	private int favorite_sell_board_no;

	public int getFavorite_no() {
		return favorite_no;
	}

	public void setFavorite_no(int favorite_no) {
		this.favorite_no = favorite_no;
	}

	public String getFavorite_user_no() {
		return favorite_user_no;
	}

	public void setFavorite_user_no(String favorite_user_no) {
		this.favorite_user_no = favorite_user_no;
	}

	public int getFavorite_sell_board_no() {
		return favorite_sell_board_no;
	}

	public void setFavorite_sell_board_no(int favorite_sell_board_no) {
		this.favorite_sell_board_no = favorite_sell_board_no;
	}
}
