package com.car.model;

public class LogDTO {
	private String log_date;
	private String log_user_no;
	private String log_user_id;
	private String log_type;

	public String getLog_date() {
		return log_date;
	}

	public void setLog_date(String log_date) {
		this.log_date = log_date;
	}

	public String getLog_user_no() {
		return log_user_no;
	}

	public void setLog_user_no(String log_user_no) {
		this.log_user_no = log_user_no;
	}

	public String getLog_user_id() {
		return log_user_id;
	}

	public void setLog_user_id(String log_user_id) {
		this.log_user_id = log_user_id;
	}

	public String getLog_type() {
		return log_type;
	}

	public void setLog_type(String log_type) {
		this.log_type = log_type;
	}

}
