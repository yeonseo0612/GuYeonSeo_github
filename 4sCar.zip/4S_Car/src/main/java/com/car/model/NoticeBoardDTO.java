package com.car.model;

public class NoticeBoardDTO {
	private int notice_board_no;
	private String notice_board_writer_id;
	private String notice_board_title;
	private String notice_board_cont;
	private String notice_board_date;
	private String notice_board_update;
	private int notice_board_hit;
	private String notice_board_file;

	public int getNotice_board_no() {
		return notice_board_no;
	}

	public void setNotice_board_no(int notice_board_no) {
		this.notice_board_no = notice_board_no;
	}

	public String getNotice_board_writer_id() {
		return notice_board_writer_id;
	}

	public void setNotice_board_writer_id(String notice_board_writer_id) {
		this.notice_board_writer_id = notice_board_writer_id;
	}

	public String getNotice_board_title() {
		return notice_board_title;
	}

	public void setNotice_board_title(String notice_board_title) {
		this.notice_board_title = notice_board_title;
	}

	public String getNotice_board_cont() {
		return notice_board_cont;
	}

	public void setNotice_board_cont(String notice_board_cont) {
		this.notice_board_cont = notice_board_cont;
	}

	public String getNotice_board_date() {
		return notice_board_date;
	}

	public void setNotice_board_date(String notice_board_date) {
		this.notice_board_date = notice_board_date;
	}

	public String getNotice_board_update() {
		return notice_board_update;
	}

	public void setNotice_board_update(String notice_board_update) {
		this.notice_board_update = notice_board_update;
	}

	public int getNotice_board_hit() {
		return notice_board_hit;
	}

	public void setNotice_board_hit(int notice_board_hit) {
		this.notice_board_hit = notice_board_hit;
	}

	public String getNotice_board_file() {
		return notice_board_file;
	}

	public void setNotice_board_file(String notice_board_file) {
		this.notice_board_file = notice_board_file;
	}

}
