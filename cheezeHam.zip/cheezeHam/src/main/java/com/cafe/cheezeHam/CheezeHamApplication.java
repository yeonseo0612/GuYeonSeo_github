package com.cafe.cheezeHam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CheezeHamApplication {

	public static void main(String[] args) {
		SpringApplication.run(CheezeHamApplication.class, args);
	}

}
